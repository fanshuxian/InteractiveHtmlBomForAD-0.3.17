#### Change

slightly modified to be valid AD10, please find the following links for more information and more functions.

#### Links to source modules for more info.

* [JSON-js](https://github.com/douglascrockford/JSON-js)

* [lz-string](https://github.com/pieroxy/lz-string)
